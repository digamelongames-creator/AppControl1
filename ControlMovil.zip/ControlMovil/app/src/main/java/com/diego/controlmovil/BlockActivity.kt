package com.diego.controlmovil

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/** Pantalla que aparece al abrir una app o web bloqueada. */
class BlockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_REASON = "reason"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Ui.dp(this, 32)
        val root = Ui.vertical(this).apply {
            gravity = Gravity.CENTER
            setPadding(p, p, p, p)
            fitsSystemWindows = true
        }
        root.addView(Ui.text(this, "⛔", 64f).apply { gravity = Gravity.CENTER })
        root.addView(Ui.gap(this, 12))
        root.addView(Ui.text(this, intent.getStringExtra(EXTRA_TITLE) ?: "Bloqueado", 24f, bold = true).apply {
            gravity = Gravity.CENTER
        })
        root.addView(Ui.gap(this, 8))
        root.addView(Ui.text(this, intent.getStringExtra(EXTRA_REASON) ?: "", 16f, R.color.muted).apply {
            gravity = Gravity.CENTER
        })
        root.addView(Ui.gap(this, 28))
        root.addView(MaterialButton(this).apply {
            text = "Volver al inicio"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { goHome() }
        })
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
