package com.diego.controlmovil

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.concurrent.Executors

class AppsActivity : AppCompatActivity() {

    private data class AppItem(val pkg: String, val label: String, val icon: Drawable?, val todayMs: Long)

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var list: LinearLayout
    private var items: List<AppItem> = emptyList()
    private var filter = ""

    private val options = listOf(
        "Sin bloqueo" to null,
        "Bloquear siempre" to Prefs.ALWAYS,
        "Límite 15 min al día" to 15,
        "Límite 30 min al día" to 30,
        "Límite 1 h al día" to 60,
        "Límite 2 h al día" to 120,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Ui.dp(this, 16)
        val root = Ui.vertical(this).apply { setPadding(p, p, p, p) }
        root.addView(Ui.text(this, "Bloquear apps", 24f, bold = true))
        root.addView(Ui.text(this, "Toca una app para bloquearla o ponerle un límite diario.", 14f, R.color.muted))
        root.addView(Ui.gap(this, 10))
        root.addView(EditText(this).apply {
            hint = "Buscar app…"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter = s.toString().trim().lowercase(); showList() }
            })
        })
        list = Ui.vertical(this)
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root); fitsSystemWindows = true })

        list.addView(Ui.text(this, "Cargando apps…", 14f, R.color.muted))
        worker.execute {
            val pm = packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val usage = if (Usage.hasAccess(this)) Usage.day(this, 0).apps.toMap() else emptyMap()
            val loaded = pm.queryIntentActivities(launcherIntent, 0)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != packageName }
                .map { pkg -> AppItem(pkg, Ui.appLabel(this, pkg), Ui.appIcon(this, pkg), usage[pkg] ?: 0L) }
                .sortedWith(compareByDescending<AppItem> { it.todayMs }.thenBy { it.label.lowercase() })
            runOnUiThread { items = loaded; showList() }
        }
    }

    private fun showList() {
        list.removeAllViews()
        val rules = Prefs.blockedApps(this)
        // Primero las bloqueadas, luego el resto por uso de hoy
        val shown = items
            .filter { filter.isEmpty() || it.label.lowercase().contains(filter) }
            .sortedByDescending { rules.containsKey(it.pkg) }
        for (app in shown) {
            val rule = rules[app.pkg]
            val row = Ui.horizontal(this).apply {
                val v = Ui.dp(this@AppsActivity, 10)
                setPadding(0, v, 0, v)
                isClickable = true
                setOnClickListener { choose(app) }
            }
            row.addView(Ui.icon(this, app.icon, 40))
            val col = Ui.vertical(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            col.addView(Ui.text(this, app.label, 16f))
            col.addView(Ui.text(this, "Hoy: ${Usage.format(app.todayMs)}", 13f, R.color.muted))
            row.addView(col)
            val (status, colorId) = when (rule) {
                null -> "" to R.color.muted
                Prefs.ALWAYS -> "Bloqueada" to R.color.danger
                else -> "Límite ${Usage.format((rule ?: 0) * 60_000L)}" to R.color.danger
            }
            row.addView(Ui.text(this, status, 13f, colorId, bold = true))
            list.addView(row)
        }
    }

    private fun choose(app: AppItem) {
        val labels = options.map { it.first }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(app.label)
            .setItems(labels) { _, which ->
                Prefs.setAppRule(this, app.pkg, options[which].second)
                showList()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
