package com.diego.controlmovil

import android.content.Context

/**
 * Configuración guardada en el móvil:
 *  - qué apps están bloqueadas (siempre o con límite diario en minutos)
 *  - qué webs están bloqueadas
 *  - interruptor general del bloqueo
 */
object Prefs {
    private const val FILE = "control_movil"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_APPS = "apps"   // entradas "paquete|minutos" (0 = siempre)
    private const val KEY_SITES = "sites" // dominios, p. ej. "instagram.com"

    const val ALWAYS = 0

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isEnabled(c: Context) = sp(c).getBoolean(KEY_ENABLED, true)
    fun setEnabled(c: Context, value: Boolean) = sp(c).edit().putBoolean(KEY_ENABLED, value).apply()

    /** paquete -> minutos al día (0 = bloqueada siempre) */
    fun blockedApps(c: Context): Map<String, Int> {
        val set = sp(c).getStringSet(KEY_APPS, emptySet()) ?: emptySet()
        val out = HashMap<String, Int>()
        for (entry in set) {
            val parts = entry.split("|")
            if (parts.size == 2) out[parts[0]] = parts[1].toIntOrNull() ?: ALWAYS
        }
        return out
    }

    /** minutes = null quita el bloqueo de esa app */
    fun setAppRule(c: Context, pkg: String, minutes: Int?) {
        val map = blockedApps(c).toMutableMap()
        if (minutes == null) map.remove(pkg) else map[pkg] = minutes
        val set = map.map { "${it.key}|${it.value}" }.toSet()
        sp(c).edit().putStringSet(KEY_APPS, HashSet(set)).apply()
    }

    fun blockedSites(c: Context): Set<String> =
        HashSet(sp(c).getStringSet(KEY_SITES, emptySet()) ?: emptySet())

    fun addSite(c: Context, site: String) {
        val set = blockedSites(c).toMutableSet()
        set.add(site)
        sp(c).edit().putStringSet(KEY_SITES, HashSet(set)).apply()
    }

    fun removeSite(c: Context, site: String) {
        val set = blockedSites(c).toMutableSet()
        set.remove(site)
        sp(c).edit().putStringSet(KEY_SITES, HashSet(set)).apply()
    }
}

object Domains {
    /**
     * Saca el dominio de lo que haya en la barra de direcciones o de lo que
     * escriba el usuario: "https://www.instagram.com/explore" -> "instagram.com".
     * Devuelve null si no parece una dirección (p. ej. una búsqueda con espacios).
     */
    fun hostOf(raw: String?): String? {
        if (raw == null) return null
        var s = raw.trim().lowercase()
        if (s.isEmpty() || s.contains(' ')) return null
        val scheme = s.indexOf("://")
        if (scheme >= 0) s = s.substring(scheme + 3)
        val cut = s.indexOfFirst { it == '/' || it == '?' || it == '#' || it == ':' }
        if (cut >= 0) s = s.substring(0, cut)
        if (s.startsWith("www.")) s = s.substring(4)
        if (!s.contains('.')) return null
        return s
    }

    /** instagram.com bloquea también m.instagram.com, help.instagram.com, etc. */
    fun matches(host: String, site: String) = host == site || host.endsWith(".$site")
}
