package com.diego.controlmovil

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import java.util.Calendar

data class DayStats(
    val dayStart: Long,
    val totalMs: Long,
    val unlocks: Int,
    /** paquete -> milisegundos en primer plano, de más a menos */
    val apps: List<Pair<String, Long>>,
)

object Usage {
    // Tipos de evento de UsageEvents.Event (con número para no depender de la versión de Android)
    private const val RESUMED = 1            // ACTIVITY_RESUMED / MOVE_TO_FOREGROUND
    private const val PAUSED = 2             // ACTIVITY_PAUSED / MOVE_TO_BACKGROUND
    private const val SCREEN_ON = 15         // SCREEN_INTERACTIVE
    private const val SCREEN_OFF = 16        // SCREEN_NON_INTERACTIVE
    private const val KEYGUARD_HIDDEN = 18   // pantalla desbloqueada

    private val IGNORED = setOf("com.android.systemui", "android")

    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun launcherPackage(c: Context): String? {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return c.packageManager.resolveActivity(home, 0)?.activityInfo?.packageName
    }

    fun startOfDay(daysAgo: Int = 0): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }.timeInMillis

    /** Estadísticas de un día: daysAgo = 0 es hoy, 1 ayer, etc. */
    fun day(c: Context, daysAgo: Int): DayStats {
        val start = startOfDay(daysAgo)
        val end = if (daysAgo == 0) System.currentTimeMillis() else startOfDay(daysAgo - 1)
        return compute(c, start, end)
    }

    /** Minutos de uso de una app hoy (para los límites diarios). */
    fun todayMsFor(c: Context, pkg: String): Long =
        day(c, 0).apps.firstOrNull { it.first == pkg }?.second ?: 0L

    private fun compute(c: Context, dayStart: Long, dayEnd: Long): DayStats {
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val launcher = launcherPackage(c)
        // Empezamos 3 h antes para saber qué app estaba abierta a medianoche.
        val events = usm.queryEvents(dayStart - 3 * 3600_000L, dayEnd)
        val perApp = HashMap<String, Long>()
        var unlocks = 0
        var screenOns = 0
        var current: String? = null
        var since = 0L

        fun close(t: Long) {
            val pkg = current ?: return
            val from = maxOf(since, dayStart)
            val to = minOf(t, dayEnd)
            if (to > from) perApp[pkg] = (perApp[pkg] ?: 0L) + (to - from)
            current = null
        }

        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val t = e.timeStamp
            when (e.eventType) {
                RESUMED -> {
                    val pkg = e.packageName
                    if (pkg != current) {
                        close(t)
                        current = pkg
                        since = t
                    }
                }
                PAUSED -> if (e.packageName == current) close(t)
                SCREEN_OFF -> close(t)
                KEYGUARD_HIDDEN -> if (t >= dayStart) unlocks++
                SCREEN_ON -> if (t >= dayStart) screenOns++
            }
        }
        close(dayEnd) // la app que sigue abierta ahora mismo

        val apps = perApp
            .filter { it.key != launcher && it.key !in IGNORED && it.value >= 1000 }
            .toList()
            .sortedByDescending { it.second }
        return DayStats(
            dayStart = dayStart,
            totalMs = apps.sumOf { it.second },
            // Si el móvil no tiene pantalla de bloqueo, contamos encendidos de pantalla
            unlocks = if (unlocks > 0) unlocks else screenOns,
            apps = apps,
        )
    }

    fun format(ms: Long): String {
        val min = ms / 60_000
        return when {
            min < 1 -> "<1 min"
            min < 60 -> "$min min"
            min % 60 == 0L -> "${min / 60} h"
            else -> "${min / 60} h ${min % 60} min"
        }
    }
}
