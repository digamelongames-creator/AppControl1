package com.diego.controlmovil

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors

/**
 * Servicio de accesibilidad: mira qué app está delante y, en los navegadores,
 * qué dirección hay en la barra. Si está bloqueada, manda al inicio y muestra
 * la pantalla de bloqueo. No guarda ni envía nada.
 */
class BlockerService : AccessibilityService() {

    /** Navegador -> id de su barra de direcciones */
    private val browsers = mapOf(
        "com.android.chrome" to "url_bar",
        "com.chrome.beta" to "url_bar",
        "com.chrome.dev" to "url_bar",
        "com.brave.browser" to "url_bar",
        "com.microsoft.emmx" to "url_bar",
        "com.kiwibrowser.browser" to "url_bar",
        "com.vivaldi.browser" to "url_bar",
        "com.sec.android.app.sbrowser" to "location_bar_edit_text",
        "org.mozilla.firefox" to "mozac_browser_toolbar_url_view",
        "org.mozilla.firefox_beta" to "mozac_browser_toolbar_url_view",
        "com.opera.browser" to "url_field",
        "com.duckduckgo.mobile.android" to "omnibarTextInput",
    )

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var launcher: String? = null
    private var currentPkg: String? = null
    private var lastUrlCheck = 0L
    private var lastBlock = 0L

    // Caché del uso de hoy por app (para los límites diarios)
    private var usageCache: Map<String, Long> = emptyMap()
    private var usageCacheAt = 0L
    private var usageLoading = false

    private val periodicCheck = object : Runnable {
        override fun run() {
            currentPkg?.let { checkApp(it) }
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        launcher = Usage.launcherPackage(this)
        handler.postDelayed(periodicCheck, 30_000L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == launcher || pkg == "com.android.systemui") {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) currentPkg = null
            return
        }
        if (!Prefs.isEnabled(this)) return

        val isWindowChange = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        if (isWindowChange || Prefs.blockedApps(this).containsKey(pkg)) {
            currentPkg = pkg
            checkApp(pkg)
        }
        if (pkg in browsers) checkUrl(pkg)
    }

    private fun checkApp(pkg: String) {
        if (!Prefs.isEnabled(this)) return
        val limit = Prefs.blockedApps(this)[pkg] ?: return
        val name = Ui.appLabel(this, pkg)
        if (limit == Prefs.ALWAYS) {
            block(name, "Has bloqueado esta app.")
            return
        }
        refreshUsageIfOld()
        val used = usageCache[pkg] ?: 0L
        if (used >= limit * 60_000L) {
            block(name, "Ya has llegado a tu límite de ${Usage.format(limit * 60_000L)} de hoy.")
        }
    }

    /** Recalcula el uso de hoy en segundo plano como mucho cada 30 s. */
    private fun refreshUsageIfOld() {
        val now = System.currentTimeMillis()
        if (usageLoading || now - usageCacheAt < 30_000L || !Usage.hasAccess(this)) return
        usageLoading = true
        worker.execute {
            val map = try { Usage.day(this, 0).apps.toMap() } catch (e: Exception) { emptyMap() }
            handler.post {
                usageCache = map
                usageCacheAt = System.currentTimeMillis()
                usageLoading = false
                currentPkg?.let { checkApp(it) }
            }
        }
    }

    private fun checkUrl(pkg: String) {
        val now = System.currentTimeMillis()
        if (now - lastUrlCheck < 400) return
        lastUrlCheck = now
        val sites = Prefs.blockedSites(this)
        if (sites.isEmpty()) return

        val root = rootInActiveWindow ?: return
        val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${browsers[pkg]}")
        val text = nodes.firstOrNull()?.text?.toString()
        val host = Domains.hostOf(text) ?: return
        val site = sites.firstOrNull { Domains.matches(host, it) } ?: return
        block(site, "Has bloqueado esta web.")
    }

    private fun block(title: String, reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 1500) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(BlockActivity.EXTRA_TITLE, title)
            putExtra(BlockActivity.EXTRA_REASON, reason)
        })
        currentPkg = null
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(periodicCheck)
        worker.shutdown()
        super.onDestroy()
    }
}
