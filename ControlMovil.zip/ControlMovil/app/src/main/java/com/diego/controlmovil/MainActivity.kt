package com.diego.controlmovil

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var daysAgo = 0
    private var week: List<DayStats> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Ui.dp(this, 16)
        root = Ui.vertical(this).apply { setPadding(p, p, p, p) }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
            fitsSystemWindows = true
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(Ui.text(this, "Control Móvil", 26f, bold = true))
        root.addView(Ui.gap(this, 12))

        val usageOk = Usage.hasAccess(this)
        val blockerOk = isBlockerEnabled()

        if (!usageOk) {
            root.addView(permissionCard(
                "Falta el acceso a datos de uso",
                "Necesario para ver tu tiempo de pantalla, desbloqueos y apps más usadas. " +
                    "Busca «Control Móvil» en la lista y actívalo.",
                "Dar acceso",
            ) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        }
        if (!blockerOk) {
            root.addView(permissionCard(
                "El bloqueador está apagado",
                "Ve a Accesibilidad → Apps instaladas → Control Móvil y actívalo.\n\n" +
                    "Si sale gris o «ajuste restringido»: Ajustes → Aplicaciones → Control Móvil → " +
                    "menú ⋮ arriba a la derecha → «Permitir ajustes restringidos», y vuelve a intentarlo.",
                "Abrir Accesibilidad",
            ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        }

        content = Ui.vertical(this)
        root.addView(content)
        if (usageOk) loadStats()

        root.addView(blockingCard(blockerOk))
    }

    // ---------- Estadísticas ----------

    private fun loadStats() {
        content.removeAllViews()
        content.addView(Ui.text(this, "Cargando…", 14f, R.color.muted))
        worker.execute {
            val days = (6 downTo 0).map { Usage.day(this, it) }
            runOnUiThread {
                week = days
                showStats()
            }
        }
    }

    private fun showStats() {
        if (week.isEmpty()) return
        content.removeAllViews()
        val stats = week[6 - daysAgo]

        // Navegación por días
        val nav = Ui.horizontal(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val prev = navButton("‹", daysAgo < 6) { daysAgo++; showStats() }
        val next = navButton("›", daysAgo > 0) { daysAgo--; showStats() }
        val title = Ui.text(this, dayTitle(stats.dayStart), 17f, bold = true).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        nav.addView(prev); nav.addView(title); nav.addView(next)
        content.addView(nav)
        content.addView(Ui.gap(this, 8))

        // Resumen del día
        val summary = Ui.card(this)
        summary.addView(Ui.text(this, "Tiempo de pantalla", 13f, R.color.muted))
        summary.addView(Ui.text(this, Usage.format(stats.totalMs), 34f, bold = true))
        summary.addView(Ui.gap(this, 10))
        val row = Ui.horizontal(this)
        row.addView(stat("Desbloqueos", stats.unlocks.toString()))
        val perUnlock = if (stats.unlocks > 0) Usage.format(stats.totalMs / stats.unlocks) else "—"
        row.addView(stat("Media por desbloqueo", perUnlock))
        summary.addView(row)
        summary.addView(Ui.gap(this, 14))

        // Últimos 7 días
        summary.addView(Ui.text(this, "Últimos 7 días", 13f, R.color.muted))
        val fmt = SimpleDateFormat("EEEEE", Locale("es", "ES"))
        summary.addView(WeekChart(this).apply {
            values = week.map { it.totalMs }
            labels = week.map { fmt.format(it.dayStart).uppercase() }
            selected = 6 - daysAgo
            onSelect = { i -> daysAgo = 6 - i; showStats() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this@MainActivity, 110)).apply {
                topMargin = Ui.dp(this@MainActivity, 8)
            }
        })
        val avg = week.map { it.totalMs }.average().toLong()
        summary.addView(Ui.text(this, "Media semanal: ${Usage.format(avg)} al día", 13f, R.color.muted).apply {
            setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0)
        })
        content.addView(summary)

        // Apps más usadas
        val apps = Ui.card(this)
        apps.addView(Ui.text(this, "Apps más usadas", 17f, bold = true))
        apps.addView(Ui.gap(this, 8))
        val top = stats.apps.take(10)
        if (top.isEmpty()) apps.addView(Ui.text(this, "Sin datos para este día.", 14f, R.color.muted))
        val max = top.firstOrNull()?.second ?: 1L
        val rules = Prefs.blockedApps(this)
        for ((pkg, ms) in top) {
            val line = Ui.horizontal(this).apply { setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0) }
            line.addView(Ui.icon(this, Ui.appIcon(this, pkg), 32))
            val col = Ui.vertical(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val head = Ui.horizontal(this)
            head.addView(Ui.text(this, Ui.appLabel(this, pkg), 15f).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                maxLines = 1
            })
            head.addView(Ui.text(this, Usage.format(ms), 14f, R.color.muted))
            col.addView(head)
            val blocked = rules.containsKey(pkg)
            col.addView(Ui.bar(this, ms.toFloat() / max, if (blocked) R.color.danger else R.color.accent))
            line.addView(col)
            apps.addView(line)
        }
        content.addView(apps)
    }

    private fun stat(label: String, value: String) = Ui.vertical(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        addView(Ui.text(this@MainActivity, value, 20f, bold = true))
        addView(Ui.text(this@MainActivity, label, 12f, R.color.muted))
    }

    private fun navButton(label: String, enabled: Boolean, onClick: () -> Unit) =
        TextView(this).apply {
            text = label
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Ui.color(this@MainActivity, if (enabled) R.color.accent else R.color.bar_bg))
            val pad = Ui.dp(this@MainActivity, 12)
            setPadding(pad, 0, pad, 0)
            isEnabled = enabled
            setOnClickListener { onClick() }
        }

    private fun dayTitle(start: Long): String = when (daysAgo) {
        0 -> "Hoy"
        1 -> "Ayer"
        else -> SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(start)
            .replaceFirstChar { it.uppercase() }
    }

    // ---------- Bloqueo ----------

    private fun blockingCard(blockerOk: Boolean) = Ui.card(this).apply {
        addView(Ui.text(this@MainActivity, "Bloqueos", 17f, bold = true))
        val apps = Prefs.blockedApps(this@MainActivity).size
        val sites = Prefs.blockedSites(this@MainActivity).size
        addView(Ui.text(this@MainActivity, "$apps apps · $sites webs", 13f, R.color.muted))
        addView(Ui.gap(this@MainActivity, 8))

        val sw = MaterialSwitch(this@MainActivity).apply {
            text = if (blockerOk) "Bloqueo activo" else "Bloqueo activo (falta activar el permiso)"
            isChecked = Prefs.isEnabled(this@MainActivity)
            setTextColor(Ui.color(this@MainActivity, R.color.text))
            setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this@MainActivity, on) }
        }
        addView(sw)
        addView(Ui.gap(this@MainActivity, 8))
        addView(MaterialButton(this@MainActivity).apply {
            text = "Bloquear apps"
            setOnClickListener { startActivity(Intent(this@MainActivity, AppsActivity::class.java)) }
        })
        addView(MaterialButton(this@MainActivity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Bloquear webs"
            setOnClickListener { startActivity(Intent(this@MainActivity, SitesActivity::class.java)) }
        })
    }

    private fun permissionCard(title: String, body: String, action: String, onClick: () -> Unit) =
        Ui.card(this).apply {
            addView(Ui.text(this@MainActivity, title, 16f, R.color.danger, bold = true))
            addView(Ui.gap(this@MainActivity, 4))
            addView(Ui.text(this@MainActivity, body, 14f, R.color.muted))
            addView(Ui.gap(this@MainActivity, 8))
            addView(MaterialButton(this@MainActivity).apply {
                text = action
                setOnClickListener { onClick() }
            })
        }

    private fun isBlockerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, BlockerService::class.java)
        return enabled.split(':').any {
            ComponentName.unflattenFromString(it) == me
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
