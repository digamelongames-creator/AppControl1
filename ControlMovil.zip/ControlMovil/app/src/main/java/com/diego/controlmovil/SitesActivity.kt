package com.diego.controlmovil

import android.os.Bundle
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

class SitesActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var list: LinearLayout
    private lateinit var chips: ChipGroup

    private val suggestions = listOf(
        "instagram.com", "youtube.com", "tiktok.com", "facebook.com",
        "x.com", "twitter.com", "reddit.com", "twitch.tv",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = Ui.dp(this, 16)
        val root = Ui.vertical(this).apply { setPadding(p, p, p, p) }
        root.addView(Ui.text(this, "Bloquear webs", 24f, bold = true))
        root.addView(Ui.text(
            this,
            "Funciona en Chrome, Samsung Internet, Firefox, Edge, Brave, Opera, Vivaldi y DuckDuckGo. " +
                "Bloquear un dominio bloquea también sus subdominios (m.instagram.com, etc.).",
            14f, R.color.muted,
        ))
        root.addView(Ui.gap(this, 12))

        val addRow = Ui.horizontal(this)
        input = EditText(this).apply {
            hint = "ej. instagram.com"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_DONE
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) { add(text.toString()); true } else false
            }
        }
        addRow.addView(input)
        addRow.addView(MaterialButton(this).apply {
            text = "Añadir"
            setOnClickListener { add(input.text.toString()) }
        })
        root.addView(addRow)

        root.addView(Ui.gap(this, 8))
        root.addView(Ui.text(this, "Sugerencias", 13f, R.color.muted))
        chips = ChipGroup(this)
        root.addView(chips)

        root.addView(Ui.gap(this, 12))
        root.addView(Ui.text(this, "Webs bloqueadas", 17f, bold = true))
        list = Ui.vertical(this)
        root.addView(list)

        setContentView(ScrollView(this).apply { addView(root); fitsSystemWindows = true })
        refresh()
    }

    private fun add(raw: String) {
        val host = Domains.hostOf(raw)
        if (host == null) {
            Toast.makeText(this, "Escribe un dominio, por ejemplo instagram.com", Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.addSite(this, host)
        input.setText("")
        refresh()
    }

    private fun refresh() {
        val sites = Prefs.blockedSites(this).sorted()

        chips.removeAllViews()
        for (s in suggestions.filter { it !in sites }) {
            chips.addView(Chip(this).apply {
                text = "+ $s"
                setOnClickListener { Prefs.addSite(this@SitesActivity, s); refresh() }
            })
        }

        list.removeAllViews()
        if (sites.isEmpty()) {
            list.addView(Ui.text(this, "Ninguna todavía.", 14f, R.color.muted).apply {
                setPadding(0, Ui.dp(this@SitesActivity, 8), 0, 0)
            })
        }
        for (site in sites) {
            val row = Ui.horizontal(this).apply {
                val v = Ui.dp(this@SitesActivity, 10)
                setPadding(0, v, 0, v)
            }
            row.addView(Ui.text(this, site, 16f).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this).apply {
                text = "Quitar"
                textSize = 14f
                setTextColor(Ui.color(this@SitesActivity, R.color.danger))
                setPadding(Ui.dp(this@SitesActivity, 12), 0, 0, 0)
                setOnClickListener { Prefs.removeSite(this@SitesActivity, site); refresh() }
            })
            list.addView(row)
        }
    }
}
