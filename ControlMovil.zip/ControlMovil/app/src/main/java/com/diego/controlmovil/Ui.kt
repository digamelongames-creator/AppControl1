package com.diego.controlmovil

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Pequeñas ayudas para montar las pantallas desde código, sin XML. */
object Ui {
    fun dp(c: Context, v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), c.resources.displayMetrics).toInt()

    fun color(c: Context, id: Int) = ContextCompat.getColor(c, id)

    fun text(
        c: Context, s: String, sizeSp: Float = 15f, colorId: Int = R.color.text,
        bold: Boolean = false,
    ) = TextView(c).apply {
        text = s
        textSize = sizeSp
        setTextColor(color(c, colorId))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun vertical(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }

    fun horizontal(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun card(c: Context) = vertical(c).apply {
        setBackgroundResource(R.drawable.card_bg)
        val p = dp(c, 16)
        setPadding(p, p, p, p)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(c, 12) }
    }

    fun gap(c: Context, h: Int) = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(c, h))
    }

    fun icon(c: Context, d: Drawable?, sizeDp: Int = 36) = ImageView(c).apply {
        setImageDrawable(d)
        layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)).apply {
            marginEnd = dp(c, 12)
        }
    }

    /** Barra horizontal de progreso (0..1). */
    fun bar(c: Context, fraction: Float, colorId: Int = R.color.accent): View {
        val row = LinearLayout(c).apply {
            background = GradientDrawable().apply {
                setColor(color(c, R.color.bar_bg)); cornerRadius = dp(c, 4).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 6)).apply {
                topMargin = dp(c, 6)
            }
        }
        val f = fraction.coerceIn(0.02f, 1f)
        row.addView(View(c).apply {
            background = GradientDrawable().apply {
                setColor(color(c, colorId)); cornerRadius = dp(c, 4).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, f)
        })
        row.addView(View(c).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f - f + 0.0001f)
        })
        return row
    }

    fun appLabel(c: Context, pkg: String): String = try {
        val info = c.packageManager.getApplicationInfo(pkg, 0)
        c.packageManager.getApplicationLabel(info).toString()
    } catch (e: Exception) {
        pkg
    }

    fun appIcon(c: Context, pkg: String): Drawable? = try {
        c.packageManager.getApplicationIcon(pkg)
    } catch (e: Exception) {
        null
    }
}

/** Gráfico de barras sencillo para los últimos 7 días. Toca una barra para ver ese día. */
class WeekChart(c: Context) : View(c) {
    var values: List<Long> = emptyList()      // ms, del más antiguo al de hoy
        set(v) { field = v; invalidate() }
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate() }
    var selected: Int = -1
        set(v) { field = v; invalidate() }
    var onSelect: ((Int) -> Unit)? = null

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = Ui.dp(c, 11).toFloat()
    }
    private val rect = RectF()

    init {
        setOnTouchListener { v, ev ->
            if (ev.action == android.view.MotionEvent.ACTION_UP && values.isNotEmpty()) {
                val i = (ev.x / (width.toFloat() / values.size)).toInt().coerceIn(0, values.size - 1)
                onSelect?.invoke(i)
                v.performClick()
            }
            true
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (values.isEmpty()) return
        val n = values.size
        val labelH = Ui.dp(context, 18).toFloat()
        val chartH = height - labelH
        val slot = width.toFloat() / n
        val barW = slot * 0.55f
        val max = (values.maxOrNull() ?: 1L).coerceAtLeast(60_000L).toFloat()
        val r = Ui.dp(context, 4).toFloat()
        textPaint.color = Ui.color(context, R.color.muted)
        for (i in 0 until n) {
            val cx = slot * i + slot / 2
            val h = (values[i] / max * (chartH - Ui.dp(context, 4))).coerceAtLeast(Ui.dp(context, 2).toFloat())
            barPaint.color = Ui.color(context, if (i == selected) R.color.accent else R.color.bar_bg)
            rect.set(cx - barW / 2, chartH - h, cx + barW / 2, chartH)
            canvas.drawRoundRect(rect, r, r, barPaint)
            if (i < labels.size) canvas.drawText(labels[i], cx, height - Ui.dp(context, 4).toFloat(), textPaint)
        }
    }
}
